import ctypes
from pathlib import Path

lib_dir = Path(__file__).resolve().parent


def _find_extension() -> Path | None:
    candidates = sorted(lib_dir.glob("igris_c_sdk_py*.so"))
    if candidates:
        return candidates[0]

    nested_dir = lib_dir / "igris_c_sdk"
    if nested_dir.is_dir():
        nested_candidates = sorted(nested_dir.glob("igris_c_sdk_py*.so"))
        if nested_candidates:
            return nested_candidates[0]

    return None


so_file = _find_extension()
if so_file is not None:
    ctypes.CDLL(str(so_file))

from .igris_c_sdk_py import *  # noqa: F401,F403

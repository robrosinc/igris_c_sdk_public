import ctypes
from importlib.metadata import PackageNotFoundError, version
from pathlib import Path

try:
    __version__ = version("igris_c_sdk")
except PackageNotFoundError:  # running from a source tree, not an installed wheel
    __version__ = "0.0.0+unknown"

lib_dir = Path(__file__).resolve().parent


def _find_extension() -> Path | None:
    candidates = sorted(lib_dir.glob("igris_c_sdk_py*.so"))
    if candidates:
        return candidates[0]

    nested_dir = lib_dir / "igris_c_sdk"
    if nested_dir.is_dir():
        nested_candidates = sorted(nested_dir.glob("igris_c_sdk_py*.so"))
        if nested_candidates:
            return nested_candidates[0]

    return None


so_file = _find_extension()
if so_file is not None:
    ctypes.CDLL(str(so_file))

from .igris_c_sdk_py import *  # noqa: F401,F403


def decode_frame_id(raw: object) -> str:
    """Read a Header.frame_id back into a str.

    The field is a fixed char[256]; pybind11 surfaces it as bytes or as a sequence of
    1-char strings depending on version, so accept both and cut at the first NUL.
    Inverse of igris_c_sdk::to_frame_id on the C++ side.
    """
    if isinstance(raw, (bytes, bytearray)):
        return bytes(raw).split(b"\x00", 1)[0].decode("utf-8", "replace")
    chars: list[str] = []
    for item in raw:  # type: ignore[union-attr]
        char = item if isinstance(item, str) else chr(item)
        if char == "\x00":
            break
        chars.append(char)
    return "".join(chars)

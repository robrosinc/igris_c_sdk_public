import os
import ctypes
from pathlib import Path

lib_dir = Path(__file__).parent
so_file = lib_dir / "igris_c_sdk.cpython-312-x86_64-linux-gnu.so"


ctypes.CDLL(str(so_file))

from .igris_c_sdk import *